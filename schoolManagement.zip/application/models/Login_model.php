<?php
class Login_model extends CI_Model{
 
    function validate($email,$password){
      $this->db->where('email',$email);
      $this->db->where('password',$password);
      $result = $this->db->get('login',1);
      return $result;
    }

    function insert($data)
    {
      $this->db->insert('login', $data);
      $insert_id = $this->db->insert_id();
      return  $insert_id;
    }

    function insertStudents($data)
    {
      $this->db->insert('students', $data);
      $insert_id = $this->db->insert_id();
      return  $insert_id;
    }

    public function getreqStudents()
    {
        $this->db->where('roal','student');
        $query=$this->db->get('login');
        $result=$query->result();
        $num_rows=$query->num_rows();
        $last_three_record=array_slice($result,-3,3,true);
        return array("all_data"=>$result,"num_rows"=>$num_rows,"last_three"=>$last_three_record);
    }

    public function getreqStudentsDetails($id)
    {
        $this->db->where('user_id',$id);
        $up=$this->db->get('students');
        return $up->row();
    }


    function insert_parent($data)
    {
      $this->db->insert('login', $data);
      $insert_id = $this->db->insert_id();
      return  $insert_id;
    }

    function insertParentstable($data)
    {
      $this->db->insert('parents', $data);
      $insert_id = $this->db->insert_id();
      return  $insert_id;
    }

    /*Teacher*/

    function insert_teacher($data)
    {
      $this->db->insert('login', $data);
      $insert_id = $this->db->insert_id();
      return  $insert_id;
    }

    function insertTeachertable($data)
    {
      $this->db->insert('teacher', $data);
      $insert_id = $this->db->insert_id();
      return  $insert_id;
    }

    function insert_class($data)
    {
      $this->db->insert('class', $data);
      $insert_id = $this->db->insert_id();
      return  $insert_id;
    }

    /*Get Class */
    
    public function getreqClass()
    {

      $this->db->select('class_name');
      $this->db->distinct();
      $query = $this->db->get('class');
      return $query->result();
    }

    public function getreqDivision($classname)
    {

      $query = $this->db->query("SELECT DISTINCT division from class where class_name='".$classname."'");
      return $query->result();
    }

    /*Get Teacher */
    public function getreqteacher()
    {
      $this->db->where('roal','teacher');
        $query=$this->db->get('login');
        if ($query->num_rows() > 0)
        {
          return $query->result();
        }
    }

    /*POST Class Teacher */

    function insert_classTeacher($data)
    {
      $this->db->insert('class_teacher', $data);
      $insert_id = $this->db->insert_id();
      return  $insert_id;
    }

    /* CHECK EXISTS */
    function checkexists($classname,$Division,$teacher)
    {
      $query = $this->db->query("SELECT * from class where class_name='".$classname."' AND division='".$Division."' OR teacher_id=".$teacher."");
      $count = $query->num_rows();
      //echo $count;
      return  $count;
    }
   
  }
?>