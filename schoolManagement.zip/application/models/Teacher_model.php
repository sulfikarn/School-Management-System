<?php
class Teacher_model extends CI_Model{
 
    function getreqTeacherDetails($email){
    //echo $email; exit;
        $this->db->where('email',$email);
        $query=$this->db->get('login');
        $result=$query->row();
        return $result;
    }

    function getreqTeacherClass($teacherId)
    {
        //echo $teacherId; exit;
        $this->db->where('teacher_id',$teacherId);
        $query=$this->db->get('class');
        $result=$query->row();
        return $result;
    }

    function getreqTeacherStudents($ClassName,$Division){
        //echo $ClassName;
        //echo $Division; exit();
        $this->db->where('class',$ClassName,'division',$Division);
        $query=$this->db->get('students');
        $result=$query->result();
        return $result;
    }

    public function getreqStudentsDetails($id)
    {
        $sql = "SELECT * FROM `login` WHERE `id` IN (".implode(',',$id).")";
        $query = $this->db->query($sql);

        // $this->db->where('id',$id);
        // $up=$this->db->get('login');
        // $result=$up->result();
        return $query->result();

    }

    

}
?>