<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Students extends CI_Controller {

	function __construct()
    {
    parent::__construct();
    $this->load->model('Login_model');
    }

	public function index()
	{
		$Class = $this->Login_model->getreqClass();
		$data['class'] = $Class;
		$this->load->view('admin/enroll_student',$data);
	}

	public function register()
    {
        if($_POST['submit'])
        {
			//echo "haiiii"; exit();
            
			$this->form_validation->set_rules('admission_no', 'Admission', 'required|trim'); 
			$this->form_validation->set_rules('name', 'Name', 'required|trim');
			$this->form_validation->set_rules('parent_name', 'Parent Name', 'required|trim');
			$this->form_validation->set_rules('relation', 'Relation', 'required|trim');
			$this->form_validation->set_rules('class', 'Class', 'required|trim');
			$this->form_validation->set_rules('division', 'Division', 'required|trim');
			$this->form_validation->set_rules('dob', 'DOB', 'required|trim');
			$this->form_validation->set_rules('gender', 'Gender', 'required|trim');
			$this->form_validation->set_rules('mob', 'Mobile', 'required|trim');
			$this->form_validation->set_rules('bld_grp', 'Blood Group', 'required|trim');
			$this->form_validation->set_rules('address', 'Address', 'required|trim');
			$this->form_validation->set_rules('adhar_no', 'Adhar No', 'required|trim');
            $this->form_validation->set_rules('email', 'Email Address', 'required|trim|valid_email|is_unique[login.email]');
            $this->form_validation->set_rules('password', 'Password', 'required');

            if($this->form_validation->run()){
                $data = array(
					'name'  => $this->input->post('name'),
					'admission_no'  => $this->input->post('admission_no'),
                    'email'  => $this->input->post('email'),
                    'password' => $this->input->post('password'),
                    'roal' => "student"
                   );
                   //$id = $this->register_model->insert($data);
                   $id = $this->Login_model->insert($data);
                   if($id>0){
                   
                    $data1 = array(
						'parent_name'  => $this->input->post('parent_name'),
						'relation'  => $this->input->post('relation'),
						'class'  => $this->input->post('class'),
						'division'  => $this->input->post('division'),
						'dob'  => $this->input->post('dob'),
						'gender'  => $this->input->post('gender'),
						'mob'  => $this->input->post('mob'),
						'bld_grp'  => $this->input->post('bld_grp'),
						'address'  => $this->input->post('address'),
						'adhar_no'  => $this->input->post('adhar_no'),
                        'user_id' => $id
                       );
					$id1 = $this->Login_model->insertStudents($data1);
					
					redirect('admin/Students');
                }else {
                    echo "Fail";
                }
            }
        } else{
            $this->load->view('register');
        }
    }

	public function view_students()
	{
		$result = $this->Login_model->getreqStudents();
		$this->load->view('admin/studentslist',$result);
	}

	public function enroll_parent()
	{
		$id = $this->uri->segment(4);
		$showd['data1']=$this->Login_model->getreqStudentsDetails($id);
		$this->load->view('admin/enroll_parent',$showd);
	}

	public function parent_register()
	{
		if($_POST['submit'])
		{
			//echo "hai"; exit();

			$this->form_validation->set_rules('parent_name', 'Parent Name', 'required|trim');
			$this->form_validation->set_rules('address', 'Address', 'required|trim');
			$this->form_validation->set_rules('mob', 'Mobile', 'required|trim');
			$this->form_validation->set_rules('email', 'Email Address', 'required|trim|valid_email|is_unique[login.email]');
			 $this->form_validation->set_rules('password', 'Password', 'required');// 
			if($this->form_validation->run()){
				//echo "hai"; exit();
				$data = array(
					'name'  => $this->input->post('parent_name'),
                    'email'  => $this->input->post('email'),
                    'password' => $this->input->post('password'),
                    'roal' => "parents"
				   );
				   $id = $this->Login_model->insert_parent($data);
				   if($id>0){
					
					$data1 = array(
					'address'  => $this->input->post('address'),
					'mob'  => $this->input->post('mob'),
					'student_id'  => $this->input->post('student_id'),
					);
					$id1 = $this->Login_model->insertParentstable($data1);
					redirect('admin/Students');
				   } else {
					echo "Fail";
				   }
				} 
			}else{
				$this->load->view('admin/enroll_parent');
			}
		}

	public function enroll_teacher()
	{
		$this->load->view('admin/enroll_teacher');
	}

	public function teacher_register(){

		if($_POST['submit'])
		{
			//echo "hai"; exit();

			$this->form_validation->set_rules('name', 'Teacher Name', 'required|trim');
			$this->form_validation->set_rules('address', 'Address', 'required|trim');
			$this->form_validation->set_rules('dob', 'Date Of Birth', 'required|trim');
			$this->form_validation->set_rules('mob', 'Mobile', 'required|trim');
			$this->form_validation->set_rules('email', 'Email Address', 'required|trim|valid_email|is_unique[login.email]');
			$this->form_validation->set_rules('password', 'Password', 'required');// 
			if($this->form_validation->run()){
				//echo "hai"; exit();
				$data = array(
					'name'  => $this->input->post('name'),
                    'email'  => $this->input->post('email'),
                    'password' => $this->input->post('password'),
                    'roal' => "teacher"
				   );
				   $id = $this->Login_model->insert_teacher($data);
				   if($id>0){
					
					$data1 = array(
					'birthday'  => $this->input->post('dob'),
					'sex'  => $this->input->post('gender'),
					'blood_group'  => $this->input->post('bld_grp'),
					'address'  => $this->input->post('address'),
					'phone'  => $this->input->post('mob'),
					'teacher_loginid' => $id
					);
					$id1 = $this->Login_model->insertTeachertable($data1);
					redirect('admin/Students/enroll_teacher');
				   } else {
					echo "Fail";
				   }
				} 
			}else{
				$this->load->view('admin/enroll_teacher');
			}
	}

	public function enroll_class(){
		$getTeacher = $this->Login_model->getreqteacher();
		$data['teacher'] = $getTeacher;
		$this->load->view('admin/enroll_class',$data);
	}

	public function add_class()
	{
		if($_POST['submit'])
		{
			$this->form_validation->set_rules('className', 'Class Name', 'required|trim');
			$this->form_validation->set_rules('division', 'Division', 'required|trim');
			$this->form_validation->set_rules('teacherName', 'Teacher Name', 'required|trim');
			if($this->form_validation->run()){

				$classname=$_POST['className'];
				$Division=$_POST['division'];
				$teacher = $_POST['teacherName'];
				$checkExists = $this->Login_model->checkexists($classname,$Division,$teacher);
				//echo $checkExists; exit;
				if($checkExists === 0){

					$data = array(
						'class_name'  => $this->input->post('className'),
						'division'  => $this->input->post('division'),
						'teacher_id'  => $this->input->post('teacherName')
					   );
					   $id = $this->Login_model->insert_class($data);
					   if($id>0){
						redirect('admin/Students/enroll_class');
						} else {
							echo "Fail";
						}
				} else{
					echo "Allredy Exists";
				}
			}
		} else {
			$this->load->view('admin/enroll_class');
		}
	}
	
	public function getDivision(){
		$form_data=array();
		$Division = array();
		if(isset($_POST['class'])){
			$result = $this->Login_model->getreqDivision($_POST['class']);
			$i=0;
			foreach ($result as $key) {
				array_push($Division,$key->division);
			}
			$form_data['success']=true;
			$form_data['divisions']=$Division;
			echo json_encode($form_data);
		}
	}
	// public function enroll_division(){
	// 	$getClass = $this->Login_model->getreqClass();
	// 	$getTeacher = $this->Login_model->getreqteacher();
	// 	$data['class'] = $getClass;
	// 	$data['teacher'] = $getTeacher;
	// 	$this->load->view('admin/enroll_division',$data);
	// }

	// public function add_classTeacher()
	// {
	// 	$getClass = $this->Login_model->getreqClass();
	// 	$getTeacher = $this->Login_model->getreqteacher();
	// 	$data['class'] = $getClass;
	// 	$data['teacher'] = $getTeacher;

	// 	if($_POST['submit'])
	// 	{
	// 		$this->form_validation->set_rules('division', 'Division', 'required|trim');
	// 		$this->form_validation->set_rules('className', 'Class Name', 'required|trim');
	// 		$this->form_validation->set_rules('teacherName', 'Teacher Name', 'required|trim');

	// 		if($this->form_validation->run()){
	// 			$data = array(
	// 				'division'  => $this->input->post('division'),
	// 				'class_id'  => $this->input->post('className'),
	// 				'teacher_id'  => $this->input->post('teacherName')
	// 			   );
	// 			   $id = $this->Login_model->insert_classTeacher($data);
	// 			   if($id>0){
	// 				redirect('admin/Students/enroll_division');
	// 				} else {
	// 					echo "Fail";
	// 				}
	// 		}
	// 	} else {
	// 		$this->load->view('admin/enroll_division',$data);
	// 	}
	// }

	public function student_promotion()
	{
		$this->load->view('admin/student_promotion');
	}
}
