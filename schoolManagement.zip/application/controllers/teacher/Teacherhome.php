<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Teacherhome extends CI_Controller {

	function __construct()
    {
    parent::__construct();
    $this->load->model('Teacher_model');
    }

	public function index()
	{
		// $students=array();
		if (isset($this->session->userdata['logged_in'])) {
			$email = ($this->session->userdata['email']);
			//echo $email; exit;
			$result = $this->Teacher_model->getreqTeacherDetails($email);
			$teacherId = $result->id;
			
			$class = $this->Teacher_model->getreqTeacherClass($teacherId);
				$teacher=$class;
				$ClassName=$teacher->class_name;
				$Division=$teacher->division;
				$class = $this->Teacher_model->getreqTeacherStudents($ClassName,$Division);
				//$students=new stdClass();
				$data=array();
				
				foreach($class as $list){
					$studentsID=$list->user_id; 
					array_push($data,$studentsID);
				}
				$students = $this->Teacher_model->getreqStudentsDetails($data);
				$stdata['class']=$students;
				//echo $data;exit;
				//print_r($students); exit;
				
				$this->load->view('teacher/dashboard',$stdata);
			// exit;
			} else {
			header("location: login");
			}

	}
}
